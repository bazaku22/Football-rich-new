import { describe, expect, it } from 'vitest';
import {
  calculateExpectedValue,
  calculateFairOdds,
  settleHandicap,
  splitHandicap,
  type SupportedHandicap
} from './handicap';

describe('Asian Handicap split', () => {
  it.each([
    [-0.25, [0, -0.5]], [-0.5, [-0.5, -0.5]], [-0.75, [-0.5, -1]],
    [-1, [-1, -1]], [-1.25, [-1, -1.5]], [-1.5, [-1.5, -1.5]],
    [-1.75, [-1.5, -2]], [-2, [-2, -2]]
  ] as Array<[SupportedHandicap, [number, number]]>)('splits %s correctly', (line, expected) => {
    expect(splitHandicap(line)).toEqual(expected);
  });
});

describe('Favorite-side settlement', () => {
  it.each([
    [-0.25, 0, 'HALF_LOSS'], [-0.25, 1, 'FULL_WIN'],
    [-0.5, 0, 'FULL_LOSS'], [-0.5, 1, 'FULL_WIN'],
    [-0.75, 1, 'HALF_WIN'], [-0.75, 0, 'FULL_LOSS'],
    [-1, 1, 'PUSH'], [-1, 2, 'FULL_WIN'],
    [-1.25, 1, 'HALF_LOSS'], [-1.25, 2, 'FULL_WIN'],
    [-1.5, 1, 'FULL_LOSS'], [-1.5, 2, 'FULL_WIN'],
    [-1.75, 2, 'HALF_WIN'], [-1.75, 1, 'FULL_LOSS'],
    [-2, 2, 'PUSH'], [-2, 3, 'FULL_WIN']
  ] as Array<[SupportedHandicap, number, string]>)('line %s with goal difference %s => %s', (line, goals, expected) => {
    expect(settleHandicap(goals, line, 1.9).settlement).toBe(expected);
  });

  it('calculates quarter-line net return for half win', () => {
    expect(settleHandicap(1, -0.75, 1.9).netReturnPerUnit).toBeCloseTo(0.45);
  });

  it('calculates a push as zero net return', () => {
    expect(settleHandicap(2, -2, 1.9).netReturnPerUnit).toBe(0);
  });

  it('rejects unsupported handicap lines', () => {
    expect(() => settleHandicap(1, -0.6 as SupportedHandicap)).toThrow(RangeError);
  });
});

describe('Fair odds and expected value', () => {
  const probabilities = { fullWin: 0.3, halfWin: 0.1, push: 0.1, halfLoss: 0.1, fullLoss: 0.4 };

  it('calculates expected value from five settlement outcomes', () => {
    expect(calculateExpectedValue(probabilities, 2)).toBeCloseTo(-0.1);
  });

  it('calculates fair odds including half outcomes', () => {
    expect(calculateFairOdds(probabilities)).toBeCloseTo(2.2857142857);
  });

  it('returns null fair odds when no winning outcome is possible', () => {
    expect(calculateFairOdds({ fullWin: 0, halfWin: 0, push: 0.2, halfLoss: 0.2, fullLoss: 0.6 })).toBeNull();
  });

  it('rejects probabilities that do not total 100%', () => {
    expect(() => calculateExpectedValue({ ...probabilities, fullWin: 0.5 }, 2)).toThrow(RangeError);
  });
});
