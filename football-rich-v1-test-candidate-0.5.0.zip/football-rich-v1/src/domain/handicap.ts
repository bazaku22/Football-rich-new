/**
 * Favorite-side Asian Handicap calculations.
 * A negative handicap represents the selected favorite giving goals.
 * Decimal odds are inclusive of returned stake (e.g. 1.90).
 */

export const SUPPORTED_HANDICAPS = [
  -0.25, -0.5, -0.75, -1, -1.25, -1.5, -1.75, -2
] as const;

export type SupportedHandicap = (typeof SUPPORTED_HANDICAPS)[number];
export type Settlement = 'FULL_WIN' | 'HALF_WIN' | 'PUSH' | 'HALF_LOSS' | 'FULL_LOSS';

export interface SettlementResult {
  settlement: Settlement;
  /** Net profit divided by original stake; excludes returned stake. */
  netReturnPerUnit: number;
  componentResults: Array<'WIN' | 'PUSH' | 'LOSS'>;
}

export interface SettlementProbabilities {
  fullWin: number;
  halfWin: number;
  push: number;
  halfLoss: number;
  fullLoss: number;
}

const EPSILON = 1e-9;

function assertSupportedHandicap(handicap: number): asserts handicap is SupportedHandicap {
  if (!SUPPORTED_HANDICAPS.some((line) => Math.abs(line - handicap) < EPSILON)) {
    throw new RangeError(`Unsupported handicap line: ${handicap}`);
  }
}

/** Split quarter-goal lines into two equally weighted adjacent lines. */
export function splitHandicap(handicap: SupportedHandicap): [number, number] {
  assertSupportedHandicap(handicap);
  const quarter = Math.abs(handicap * 4) % 2 === 1;
  if (!quarter) return [handicap, handicap];
  const lowerMagnitude = Math.floor(Math.abs(handicap) * 2) / 2;
  const first = -lowerMagnitude;
  const second = -(lowerMagnitude + 0.5);
  return [first, second];
}

function settleHalfLine(goalDifference: number, handicap: number): 'WIN' | 'PUSH' | 'LOSS' {
  const adjusted = goalDifference + handicap;
  if (adjusted > 0) return 'WIN';
  if (Math.abs(adjusted) < EPSILON) return 'PUSH';
  return 'LOSS';
}

export function settleHandicap(
  goalDifference: number,
  handicap: SupportedHandicap,
  decimalOdds = 2
): SettlementResult {
  assertSupportedHandicap(handicap);
  if (!Number.isInteger(goalDifference)) throw new TypeError('Goal difference must be an integer.');
  if (!Number.isFinite(decimalOdds) || decimalOdds <= 1) throw new RangeError('Decimal odds must be greater than 1.');

  const [lineA, lineB] = splitHandicap(handicap);
  const results = lineA === lineB
    ? [settleHalfLine(goalDifference, lineA), settleHalfLine(goalDifference, lineB)]
    : [settleHalfLine(goalDifference, lineA), settleHalfLine(goalDifference, lineB)];

  const winCount = results.filter((value) => value === 'WIN').length;
  const pushCount = results.filter((value) => value === 'PUSH').length;
  const lossCount = results.filter((value) => value === 'LOSS').length;
  const netReturnPerUnit = (winCount * (decimalOdds - 1) - lossCount) / 2;

  let settlement: Settlement;
  if (winCount === 2) settlement = 'FULL_WIN';
  else if (winCount === 1 && pushCount === 1) settlement = 'HALF_WIN';
  else if (pushCount === 2) settlement = 'PUSH';
  else if (lossCount === 1 && pushCount === 1) settlement = 'HALF_LOSS';
  else settlement = 'FULL_LOSS';

  return { settlement, netReturnPerUnit, componentResults: results };
}

function validateProbabilities(p: SettlementProbabilities): void {
  const values = [p.fullWin, p.halfWin, p.push, p.halfLoss, p.fullLoss];
  if (values.some((value) => !Number.isFinite(value) || value < 0 || value > 1)) {
    throw new RangeError('Each probability must be between 0 and 1.');
  }
  const total = values.reduce((sum, value) => sum + value, 0);
  if (Math.abs(total - 1) > 1e-6) {
    throw new RangeError(`Probabilities must sum to 1. Current total: ${total}`);
  }
}

export function calculateExpectedValue(p: SettlementProbabilities, decimalOdds: number): number {
  validateProbabilities(p);
  if (!Number.isFinite(decimalOdds) || decimalOdds <= 1) throw new RangeError('Decimal odds must be greater than 1.');
  return p.fullWin * (decimalOdds - 1)
    + p.halfWin * (decimalOdds - 1) / 2
    - p.halfLoss / 2
    - p.fullLoss;
}

export function calculateFairOdds(p: SettlementProbabilities): number | null {
  validateProbabilities(p);
  const winningWeight = p.fullWin + p.halfWin / 2;
  if (winningWeight <= EPSILON) return null;
  return 1 + (p.fullLoss + p.halfLoss / 2) / winningWeight;
}
