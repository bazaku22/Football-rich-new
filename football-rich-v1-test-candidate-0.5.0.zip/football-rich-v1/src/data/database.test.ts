import { describe, expect, it } from 'vitest';
import { validateBackup } from './database';
import { STORE_NAMES, type DatabaseBackup } from './schema';

function emptyBackup(): DatabaseBackup {
  const stores = Object.fromEntries(STORE_NAMES.map((name) => [name, []])) as unknown as DatabaseBackup['stores'];
  return { format: 'football-rich-backup', backupVersion: 1, schemaVersion: 1, exportedAt: new Date(0).toISOString(), stores };
}

describe('backup validation', () => {
  it('accepts a valid empty backup with all stores', () => {
    expect(() => validateBackup(emptyBackup())).not.toThrow();
  });

  it('rejects an unsupported backup format', () => {
    expect(() => validateBackup({ ...emptyBackup(), format: 'other' })).toThrow(/invalid/i);
  });

  it('rejects a missing store', () => {
    const backup = emptyBackup();
    delete (backup.stores as Partial<DatabaseBackup['stores']>).matches;
    expect(() => validateBackup(backup)).toThrow(/missing store/i);
  });

  it('rejects records without IDs', () => {
    const backup = emptyBackup();
    (backup.stores.matches as unknown[]).push({ homeTeam: 'A' });
    expect(() => validateBackup(backup)).toThrow(/valid ID/i);
  });

  it('rejects duplicate IDs within a store', () => {
    const backup = emptyBackup();
    (backup.stores.matches as unknown[]).push({ id: 'same' }, { id: 'same' });
    expect(() => validateBackup(backup)).toThrow(/duplicate ID/i);
  });

  it('rejects a research record linked to a missing match', () => {
    const backup = emptyBackup();
    (backup.stores.research_records as unknown[]).push({ id: 'research-1', matchId: 'missing-match' });
    expect(() => validateBackup(backup)).toThrow(/missing match/i);
  });

  it('rejects a performance record linked to a missing prediction', () => {
    const backup = emptyBackup();
    (backup.stores.performance_records as unknown[]).push({ id: 'performance-1', predictionId: 'missing-prediction' });
    expect(() => validateBackup(backup)).toThrow(/missing prediction/i);
  });
});
