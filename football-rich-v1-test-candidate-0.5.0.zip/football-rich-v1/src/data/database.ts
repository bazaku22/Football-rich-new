import {
  DB_NAME, DB_VERSION, STORE_NAMES,
  type DatabaseBackup, type StoreName, type StoreRecordMap
} from './schema.js';

let databasePromise: Promise<IDBDatabase> | undefined;

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('IndexedDB request failed.'));
  });
}

export function openDatabase(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') return Promise.reject(new Error('IndexedDB is unavailable in this browser.'));
  if (databasePromise) return databasePromise;

  databasePromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      for (const storeName of STORE_NAMES) {
        if (!db.objectStoreNames.contains(storeName)) {
          const store = db.createObjectStore(storeName, { keyPath: 'id' });
          if (storeName !== 'app_settings') store.createIndex('createdAt', 'createdAt', { unique: false });
          if (storeName !== 'matches' && storeName !== 'app_settings') store.createIndex('matchId', 'matchId', { unique: false });
          if (storeName === 'matches') store.createIndex('kickoffAt', 'kickoffAt', { unique: false });
          if (storeName === 'app_settings') store.createIndex('key', 'key', { unique: true });
        }
      }
    };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => { db.close(); databasePromise = undefined; };
      resolve(db);
    };
    request.onerror = () => { databasePromise = undefined; reject(request.error ?? new Error('Could not open local database.')); };
    request.onblocked = () => reject(new Error('Database upgrade is blocked by another open Football rich tab.'));
  });
  return databasePromise;
}

export async function putRecord<K extends StoreName>(storeName: K, record: StoreRecordMap[K]): Promise<void> {
  const db = await openDatabase();
  const tx = db.transaction(storeName, 'readwrite');
  tx.objectStore(storeName).put(record);
  await transactionDone(tx);
}

export async function addRecord<K extends StoreName>(storeName: K, record: StoreRecordMap[K]): Promise<void> {
  const db = await openDatabase();
  const tx = db.transaction(storeName, 'readwrite');
  tx.objectStore(storeName).add(record);
  await transactionDone(tx);
}

export async function getRecord<K extends StoreName>(storeName: K, id: string): Promise<StoreRecordMap[K] | undefined> {
  const db = await openDatabase();
  const tx = db.transaction(storeName, 'readonly');
  const result = await requestResult(tx.objectStore(storeName).get(id)) as StoreRecordMap[K] | undefined;
  await transactionDone(tx);
  return result;
}

export async function listRecords<K extends StoreName>(storeName: K): Promise<StoreRecordMap[K][]> {
  const db = await openDatabase();
  const tx = db.transaction(storeName, 'readonly');
  const result = await requestResult(tx.objectStore(storeName).getAll()) as StoreRecordMap[K][];
  await transactionDone(tx);
  return result;
}

export async function deleteRecord<K extends StoreName>(storeName: K, id: string): Promise<void> {
  const db = await openDatabase();
  const tx = db.transaction(storeName, 'readwrite');
  tx.objectStore(storeName).delete(id);
  await transactionDone(tx);
}

function transactionDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error('Database transaction failed.'));
    tx.onabort = () => reject(tx.error ?? new Error('Database transaction was aborted.'));
  });
}

export async function exportBackup(): Promise<DatabaseBackup> {
  const entries = await Promise.all(STORE_NAMES.map(async (name) => [name, await listRecords(name)] as const));
  const stores = Object.fromEntries(entries) as DatabaseBackup['stores'];
  return { format: 'football-rich-backup', backupVersion: 1, schemaVersion: DB_VERSION, exportedAt: new Date().toISOString(), stores };
}

export function validateBackup(input: unknown): asserts input is DatabaseBackup {
  if (!input || typeof input !== 'object') throw new TypeError('Backup must be a JSON object.');
  const backup = input as Partial<DatabaseBackup>;
  if (backup.format !== 'football-rich-backup' || backup.backupVersion !== 1 || !backup.stores) {
    throw new TypeError('Unsupported or invalid Football rich backup file.');
  }
  for (const name of STORE_NAMES) {
    const rows = backup.stores[name];
    if (!Array.isArray(rows)) throw new TypeError(`Backup is missing store: ${name}`);
    const ids = new Set<string>();
    for (const row of rows as unknown[]) {
      if (!row || typeof row !== 'object' || typeof (row as { id?: unknown }).id !== 'string' || !(row as { id: string }).id) {
        throw new TypeError(`Store ${name} contains a record without a valid ID.`);
      }
      const id = (row as { id: string }).id;
      if (ids.has(id)) throw new TypeError(`Store ${name} contains duplicate ID: ${id}`);
      ids.add(id);
    }
  }
  const matchIds = new Set(backup.stores.matches.map((row) => row.id));
  const linkedStores: StoreName[] = ['research_records', 'source_evidence', 'team_news', 'market_odds', 'analyses', 'predictions', 'match_results'];
  for (const name of linkedStores) {
    for (const row of backup.stores[name] as Array<{ matchId?: unknown }>) {
      if (typeof row.matchId !== 'string' || !matchIds.has(row.matchId)) {
        throw new TypeError(`Store ${name} contains a record linked to a missing match.`);
      }
    }
  }
  const predictionIds = new Set(backup.stores.predictions.map((row) => row.id));
  for (const row of backup.stores.performance_records) {
    if (!predictionIds.has(row.predictionId)) throw new TypeError('Performance record references a missing prediction.');
  }
  const analysisIds = new Set(backup.stores.analyses.map((row) => row.id));
  for (const row of backup.stores.predictions) {
    if (row.analysisId && !analysisIds.has(row.analysisId)) throw new TypeError('Prediction references a missing analysis.');
    if (!Number.isFinite(row.selectedOdds) || row.selectedOdds <= 1) throw new TypeError('Prediction contains invalid decimal odds.');
  }
  for (const row of backup.stores.market_odds) {
    if (!Number.isFinite(row.decimalOdds) || row.decimalOdds <= 1) throw new TypeError('Market odds contain invalid decimal odds.');
  }
  for (const row of backup.stores.match_results) {
    if (!Number.isInteger(row.homeGoals) || !Number.isInteger(row.awayGoals) || row.homeGoals < 0 || row.awayGoals < 0) {
      throw new TypeError('Match result contains invalid goal values.');
    }
  }
  const supportedLines = new Set([-0.25, -0.5, -0.75, -1, -1.25, -1.5, -1.75, -2]);
  for (const row of backup.stores.predictions) {
    if (!supportedLines.has(row.selectedLine)) throw new TypeError('Prediction contains an unsupported handicap line.');
    const probs = row.snapshot?.probabilities as Record<string, unknown> | undefined;
    if (probs) {
      const keys = ['fullWin', 'halfWin', 'push', 'halfLoss', 'fullLoss'];
      const values = keys.map((key) => probs[key]);
      if (values.some((value) => typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 1)) {
        throw new TypeError('Prediction contains invalid settlement probabilities.');
      }
      const total = (values as number[]).reduce((sum, value) => sum + value, 0);
      if (Math.abs(total - 1) > 1e-6) throw new TypeError('Prediction settlement probabilities must sum to 1.');
    }
  }
  for (const row of backup.stores.analyses) {
    if (row.confidence !== undefined && (!Number.isFinite(row.confidence) || row.confidence < 0 || row.confidence > 100)) {
      throw new TypeError('Analysis contains invalid confidence.');
    }
    const probs = row.probabilities;
    if (probs && ['homeWin', 'draw', 'awayWin'].some((key) => typeof probs[key] !== 'number' || !Number.isFinite(probs[key]) || probs[key] < 0 || probs[key] > 100)) {
      throw new TypeError('Analysis contains invalid 1X2 probabilities.');
    }
    if (probs && Math.abs(Number(probs.homeWin) + Number(probs.draw) + Number(probs.awayWin) - 100) > 0.11) {
      throw new TypeError('Analysis 1X2 probabilities must sum to 100%.');
    }
  }
  const settingKeys = new Set<string>();
  for (const row of backup.stores.app_settings) {
    if (!row.key || settingKeys.has(row.key)) throw new TypeError('Settings contain a missing or duplicate key.');
    settingKeys.add(row.key);
  }
}

export async function importBackup(input: unknown, mode: 'merge' | 'replace' = 'merge'): Promise<{ imported: number; skipped: number }> {
  validateBackup(input);
  const backup = input as DatabaseBackup;
  const db = await openDatabase();
  let imported = 0;
  let skipped = 0;
  const tx = db.transaction([...STORE_NAMES], 'readwrite');
  const done = transactionDone(tx);
  try {
    const existingKeys = mode === 'merge'
      ? await Promise.all(STORE_NAMES.map((name) => requestResult(tx.objectStore(name).getAllKeys())))
      : STORE_NAMES.map(() => [] as IDBValidKey[]);
    for (let index = 0; index < STORE_NAMES.length; index += 1) {
      const name = STORE_NAMES[index];
      const store = tx.objectStore(name);
      if (mode === 'replace') store.clear();
      const ids = new Set(existingKeys[index].map(String));
      for (const row of backup.stores[name] as Array<{ id: string }>) {
        if (mode === 'merge' && ids.has(row.id)) { skipped += 1; continue; }
        store.put(row);
        imported += 1;
      }
    }
    await done;
    return { imported, skipped };
  } catch (error) {
    try { tx.abort(); } catch { /* transaction may already be inactive */ }
    throw error;
  }
}

export function downloadBackupFile(backup: DatabaseBackup): void {
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `football-rich-backup-${new Date().toISOString().slice(0, 10)}.json`;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
