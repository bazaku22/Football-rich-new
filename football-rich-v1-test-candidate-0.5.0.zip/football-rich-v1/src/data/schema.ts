export const DB_NAME = 'football-rich-local';
export const DB_VERSION = 1;

export const STORE_NAMES = [
  'matches', 'research_records', 'source_evidence', 'team_news', 'market_odds',
  'analyses', 'predictions', 'match_results', 'performance_records', 'app_settings'
] as const;

export type StoreName = (typeof STORE_NAMES)[number];

export interface BaseRecord {
  id: string;
  createdAt: string;
  updatedAt: string;
}

export interface MatchRecord extends BaseRecord {
  league: string;
  homeTeam: string;
  awayTeam: string;
  kickoffAt: string;
  status: 'UPCOMING' | 'FINISHED' | 'CANCELLED';
  notes?: string;
}

export interface ResearchRecord extends BaseRecord {
  matchId: string;
  researchType: string;
  content: string;
}

export interface SourceEvidenceRecord extends BaseRecord {
  matchId: string;
  sourceName: string;
  url: string;
  retrievedAt: string;
  verificationStatus: 'VERIFIED' | 'PARTIALLY_VERIFIED' | 'UNVERIFIED' | 'UNAVAILABLE';
  notes?: string;
}

export interface TeamNewsRecord extends BaseRecord {
  matchId: string;
  team: string;
  newsType: string;
  description: string;
  confidence?: number;
}

export interface MarketOddsRecord extends BaseRecord {
  matchId: string;
  bookmaker?: string;
  handicapLine: number;
  decimalOdds: number;
  capturedAt: string;
}

export interface AnalysisRecord extends BaseRecord {
  matchId: string;
  version: number;
  summary: string;
  confidence?: number;
  probabilities?: Record<string, number>;
}

export interface PredictionRecord extends BaseRecord {
  matchId: string;
  analysisId?: string;
  selectedLine: number;
  selectedOdds: number;
  status: 'DRAFT' | 'CONFIRMED' | 'SETTLED' | 'VOID';
  snapshot: Record<string, unknown>;
}

export interface MatchResultRecord extends BaseRecord {
  matchId: string;
  homeGoals: number;
  awayGoals: number;
  verifiedAt?: string;
}

export interface PerformanceRecord extends BaseRecord {
  predictionId: string;
  settlement: string;
  simulatedProfit: number;
  evaluatedAt: string;
}

export interface AppSettingRecord extends BaseRecord {
  key: string;
  value: unknown;
}

export interface StoreRecordMap {
  matches: MatchRecord;
  research_records: ResearchRecord;
  source_evidence: SourceEvidenceRecord;
  team_news: TeamNewsRecord;
  market_odds: MarketOddsRecord;
  analyses: AnalysisRecord;
  predictions: PredictionRecord;
  match_results: MatchResultRecord;
  performance_records: PerformanceRecord;
  app_settings: AppSettingRecord;
}

export interface DatabaseBackup {
  format: 'football-rich-backup';
  backupVersion: 1;
  schemaVersion: number;
  exportedAt: string;
  stores: { [K in StoreName]: StoreRecordMap[K][] };
}
