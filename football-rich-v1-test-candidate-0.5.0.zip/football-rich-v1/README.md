# Football rich — V1 Local MVP (Test Candidate 0.5.0)

Private, Thai-first, local-first Android-focused PWA for football research records, favorite-side Asian Handicap calculations, prediction snapshots and simulated performance tracking.

## Included workflows
- Dashboard with local record counts
- Create and list matches
- Research notes and source evidence with verification status
- Team news and market odds records
- Analysis notes, confidence and validated 1X2 probability record
- Confirmed favorite-side predictions with selected home/away team, handicap line, decimal odds and five settlement probabilities
- Asian Handicap settlement, Fair Odds and Expected Value calculator
- Match result entry and simulated settlement/performance tracking
- Prediction history
- JSON backup export and validated merge/replace import
- CSV export of matches and prediction summary
- PWA manifest, service worker and app icons

## Tech stack
- Vite + TypeScript
- IndexedDB, ten stores
- PWA manifest and service worker
- No backend, cloud database, football data API or AI API

## Requirements
- Node.js 20+

## Run locally
```bash
npm install
npm run dev
```

## Build and verification
```bash
npm install
npm run build
npm run test:smoke
```

The static production files are written to `dist/`. Serve that folder over HTTPS (or localhost) to install the PWA. `npm test` runs the additional Vitest suite when dependencies are installed. `npm run test:smoke` now also validates the sample backup, backup relationship/probability guards, calculation edge cases and required production assets.

## First test on Android
1. Build the project using the commands above.
2. Host the contents of `dist/` on a private HTTPS test origin. Do not use a public URL if you do not want the app accessible to others.
3. Open that HTTPS URL in Chrome on Android, wait for the app shell to load, then use Chrome's menu → **Install app** or **Add to Home screen** if offered.
4. Open the installed app and go to **ตั้งค่า** → **กู้คืนข้อมูล**. Import `test-data/sample-backup.json` using **นำเข้าแบบผสาน**. This fixture contains clearly marked fictional/demo records, not real match research or betting advice.
5. Check all screens: dashboard counts, match list, research/evidence, analysis, handicap calculator, prediction history and performance.
6. On the upcoming demo match, create a second prediction or use the existing confirmed sample prediction to test result entry. Record a test score and confirm settlement/performance update.
7. Export a JSON backup. Then use **แทนที่ข้อมูลทั้งหมด** only after confirming the warning, and import the exported backup to verify restoration.
8. With the app loaded, enable airplane mode and reopen it. Confirm the app shell opens; restore connectivity before relying on any external research links.
9. To remove demo data, export anything you want to keep, then use the replace-import flow with a valid empty backup or clear the site's storage in Chrome settings.

## Test fixture warning
`test-data/sample-backup.json` is synthetic demonstration data. Its teams, probabilities, odds, research notes and result are not live or verified. The example source URL is intentionally `example.com`. Do not use these values to make betting decisions.

## Important calculation notes
- Negative handicap lines represent the selected favorite giving goals.
- The user must select whether the favorite is the home or away team when recording a prediction.
- Quarter lines split stake equally across adjacent lines.
- `goalDifference` is selected favorite goals minus opponent goals.
- Decimal odds must be greater than 1 and include returned stake.
- The five settlement probabilities must sum to 100%.
- Expected value and simulated profit are per one-unit stake; they are not actual financial returns.
- Fair Odds are unavailable when the winning probability weight is zero.

## Privacy and limitations
- Records are stored in IndexedDB in the current browser profile on this device.
- The app does not send saved records to a server.
- Research and analysis must be performed externally; results are then manually saved in the app.
- No live scores, automatic odds feeds, multi-device sync or automatic AI analysis.
- Browser storage may be cleared. Export JSON backups regularly and keep them outside the browser.
- This source package has not been deployed or verified on a real Android device. The static production build has been generated and TypeScript compilation plus 80 settlement smoke-test combinations passed. Full Vitest and real-device Android/PWA installation tests remain pending. A headless browser check could not complete in the current execution environment. Test installation and offline behavior on the intended hosting origin before relying on it.
