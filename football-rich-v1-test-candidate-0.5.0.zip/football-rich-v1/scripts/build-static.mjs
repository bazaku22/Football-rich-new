import { cp, mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = process.cwd();
const dist = resolve(root, 'dist');
await mkdir(resolve(dist, 'styles'), { recursive: true });
await cp(resolve(root, 'src/styles/main.css'), resolve(dist, 'styles/main.css'));
await cp(resolve(root, 'public'), dist, { recursive: true });
const html = await readFile(resolve(root, 'index.html'), 'utf8');
await writeFile(resolve(dist, 'index.html'), html);
console.log('Static PWA build created in dist/. Serve dist/ over HTTPS or localhost.');
