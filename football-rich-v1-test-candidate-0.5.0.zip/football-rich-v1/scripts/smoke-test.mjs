import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { readFile, access } from 'node:fs/promises';

const load = async (path) => import(pathToFileURL(resolve(path)).href);
const engine = await load('dist/domain/handicap.js');
const database = await load('dist/data/database.js');
let settlementCases = 0;
for (const line of engine.SUPPORTED_HANDICAPS) {
  for (let goalDifference = -5; goalDifference <= 7; goalDifference += 1) {
    const result = engine.settleHandicap(goalDifference, line, 1.9);
    const split = engine.splitHandicap(line);
    const expected = split.map((part) => goalDifference + part > 0 ? 'WIN' : goalDifference + part === 0 ? 'PUSH' : 'LOSS');
    assert.deepEqual(result.componentResults, expected, `settlement ${line} / ${goalDifference}`);
    assert.ok(Number.isFinite(result.netReturnPerUnit));
    settlementCases += 1;
  }
}
const probabilities = { fullWin: 0.4, halfWin: 0.1, push: 0.1, halfLoss: 0.1, fullLoss: 0.3 };
assert.ok(Math.abs(engine.calculateExpectedValue(probabilities, 1.9) - 0.055) < 1e-10);
assert.ok(Math.abs(engine.calculateFairOdds(probabilities) - 1.7777777777777777) < 1e-10);
assert.throws(() => engine.calculateExpectedValue({ ...probabilities, fullLoss: 0.4 }, 1.9));
assert.equal(engine.calculateFairOdds({ fullWin: 0, halfWin: 0, push: 0.2, halfLoss: 0.2, fullLoss: 0.6 }), null);
assert.throws(() => engine.settleHandicap(1.5, -0.5, 1.9), /integer/i);

const sample = JSON.parse(await readFile(resolve('test-data/sample-backup.json'), 'utf8'));
database.validateBackup(sample);
const brokenLink = structuredClone(sample);
brokenLink.stores.research_records[0].matchId = 'not-a-real-match';
assert.throws(() => database.validateBackup(brokenLink), /missing match/i);
const brokenProbability = structuredClone(sample);
brokenProbability.stores.predictions[0].snapshot.probabilities.fullWin = 0.99;
assert.throws(() => database.validateBackup(brokenProbability), /sum to 1/i);
const brokenLine = structuredClone(sample);
brokenLine.stores.predictions[0].selectedLine = -0.6;
assert.throws(() => database.validateBackup(brokenLine), /unsupported handicap/i);

const requiredFiles = [
  'dist/index.html', 'dist/main.js', 'dist/pwa.js', 'dist/data/database.js',
  'dist/data/schema.js', 'dist/domain/handicap.js', 'dist/styles/main.css',
  'dist/manifest.webmanifest', 'dist/sw.js', 'dist/icon-192.png', 'dist/icon-512.png'
];
for (const file of requiredFiles) await access(resolve(file));
const html = await readFile(resolve('dist/index.html'), 'utf8');
assert.match(html, /lang="th"/);
assert.match(html, /manifest\.webmanifest/);
const serviceWorker = await readFile(resolve('dist/sw.js'), 'utf8');
for (const path of ['/main.js', '/data/database.js', '/domain/handicap.js', '/styles/main.css']) {
  assert.ok(serviceWorker.includes(path), `service worker shell missing ${path}`);
}
console.log(`Smoke tests passed: ${settlementCases} handicap combinations, Fair Odds, EV, input guards, backup validation, sample fixture and ${requiredFiles.length} build assets.`);
